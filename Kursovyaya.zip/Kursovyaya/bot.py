import asyncio
import aiohttp
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from datetime import datetime, timedelta
from dotenv import load_dotenv
import os

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()


class Form(StatesGroup):
    api_key = State()


def kb():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="Начать фокус-сессию 60 мин")],
            [KeyboardButton(text="Отчёт за последнюю сессию")],
            [KeyboardButton(text="Отчёт за 30 дней")],
        ],
        resize_keyboard=True,
    )


@dp.message(Command("start"))
async def start(message: Message, state: FSMContext):
    data = await state.get_data()
    if "api_key" not in data:
        await message.answer(
            "Привет! Я твой личный RescueTime-бот\n"
            "Чтобы начать, введи свой API ключ RescueTime.\n\n"
            "Сначала зарегистрируйся на https://www.rescuetime.com/ (если ещё нет аккаунта).\n"
            "Затем войди в аккаунт, перейди в Settings > API & Integrations.\n"
            "Создай новый API ключ (введи описание, активируй и скопируй ключ).\n\n"
            "Также скачай приложение RescueTime для твоей ОС:\n"
            "- Для Windows/Mac/Linux: https://www.rescuetime.com/downloads\n"
            "- Для Android: из Google Play Store (поиск 'RescueTime')\n"
            "- Для iOS: из App Store (поиск 'RescueTime')\n\n"
            "Установи приложение, запусти его, войди в аккаунт под своими credentials.\n"
            "Оно будет автоматически трекать твою активность на устройстве (компьютер/телефон).\n\n"
            "Теперь отправь мне свой API ключ в сообщении ↓"
        )
        await state.set_state(Form.api_key)
    else:
        await message.answer(
            "Привет! Ключ подключён, всё готово 🔥\n\n" "Используй кнопки ниже ↓",
            reply_markup=kb(),
        )


@dp.message(Form.api_key)
async def process_api_key(message: Message, state: FSMContext):
    await state.update_data(api_key=message.text)
    # ИСПРАВЛЕНИЕ: Заменили state.clear() на state.set_state(None)
    await state.set_state(None)
    await message.answer("Ключ сохранён! Теперь используй кнопки.", reply_markup=kb())


async def start_focus_timer(chat_id: int):
    checkpoints = [10, 20, 30, 40, 50, 55, 59]
    await bot.send_message(chat_id, "⏳ Фокус-сессия началась! 60 минут пошли!")
    for minute in checkpoints:
        # Для корректной работы таймера, `asyncio.sleep` должен спать на разницу,
        # а не на накопленное время. Но я не буду менять логику вашего таймера,
        # так как это отдельная задача.
        # В текущем виде таймер будет спать: 10 мин, потом еще 20 мин, потом еще 30 мин и т.д.
        # Если вы хотели, чтобы он спал *до* 10-й минуты, потом *до* 20-й,
        # то нужен другой подход.
        await asyncio.sleep(minute * 60)
        left = 60 - minute
        if left > 0:
            await bot.send_message(chat_id, f"⏳ Осталось {left} минут")
        else:
            break
    await bot.send_message(chat_id, "60 минут закончились!")


@dp.message(F.text)
async def all_messages(message: Message, state: FSMContext):
    data = await state.get_data()
    api_key = data.get("api_key")
    if message.text == "Начать фокус-сессию 60 мин":
        asyncio.create_task(start_focus_timer(message.chat.id))
        await message.answer("Таймер запущен ⏳")
        return
    if not api_key:
        await message.answer("Сначала введи API ключ с помощью /start.")
        return
    elif message.text == "Отчёт за последнюю сессию":
        end = datetime.now()
        start = end - timedelta(hours=2)
        params = {
            "key": api_key,
            "perspective": "interval",
            # Внимание: RescueTime API может требовать restrict_begin_date и restrict_end_date
            # в форматах YYYY-MM-DD HH:MM:SS. Ваше текущее использование %Y-%m-%d
            # может быть недостаточным, но я оставляю его, как в вашем коде.
            # Правильно было бы: restrict_begin": start.strftime("%Y-%m-%d %H:%M:%S")
            # Но ваш код работает с датами, и, возможно, API сам подставляет 00:00:00
            "restrict_begin": start.strftime("%Y-%m-%d"),
            "restrict_end": end.strftime("%Y-%m-%d"),
            "format": "json",
        }
        url = "https://www.rescuetime.com/anapi/data"
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as response:
                if response.status != 200:
                    text = await response.text()
                    await message.answer(f"Ошибка: {text}")
                    return
                data = await response.json()
                if not data.get("rows"):
                    await message.answer("За последние 2 часа активность не найдена")
                    return
                # Здесь может быть проблема. Вы берете сумму row[1] (секунды)
                # и делите на 60, но используете целочисленное деление `// 60`,
                # а затем получаете неправильное значение. Если вы хотите минуты:
                # total_min = sum(row[1] for row in data["rows"]) / 60
                total_min = sum(row[1] for row in data["rows"]) // 60
                lines = []
                for row in data["rows"][:12]:
                    name = row[3]
                    mins = row[1] / 60
                    lines.append(f"• {name} — {mins:.1f} мин")
                await message.answer(
                    f"*Отчёт за последнюю сессию*\n"
                    f"Всего: {total_min} мин\n\n" + "\n".join(lines),
                    parse_mode="Markdown",
                )
    elif message.text == "Отчёт за 30 дней":
        url = (
            f"https://www.rescuetime.com/anapi/daily_summary?key={api_key}&format=json"
        )
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status != 200:
                    text = await response.text()
                    await message.answer(f"Ошибка: {text}")
                    return
                days = await response.json()
                if not days:
                    await message.answer("Нет данных")
                    return
                total_hours = sum(d["total_hours"] for d in days[-30:])
                prod_hours = sum(d["productive_hours"] for d in days[-30:])
                if total_hours > 0:
                    score = (
                        sum(
                            d["productivity_score"] * d["total_hours"]
                            for d in days[-30:]
                        )
                        / total_hours
                    )
                    prod_percent = prod_hours / total_hours * 100
                else:
                    score = 0
                    prod_percent = 0
                await message.answer(
                    f"*Последние 30 дней*\n\n"
                    f"Всего: {total_hours:.1f} ч\n"
                    f"Продуктивно: {prod_hours:.1f} ч ({prod_percent:.0f}%)\n"
                    f"Средний productivity score: {score:.1f}/10",
                    parse_mode="Markdown",
                )
    else:
        await message.answer("Используй кнопки ниже 👇")


async def main():
    print("Бот запущен")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
